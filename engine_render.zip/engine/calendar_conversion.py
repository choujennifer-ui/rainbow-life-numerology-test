from datetime import date

LUNAR_INFO = [19416, 19168, 42352, 21717, 53856, 55632, 91476, 22176, 39632, 21970, 19168, 42422, 42192, 53840, 119381, 46400, 54944, 44450, 38320, 84343, 18800, 42160, 46261, 27216, 27968, 109396, 11104, 38256, 21234, 18800, 25958, 54432, 59984, 28309, 23248, 11104, 100067, 37600, 116951, 51536, 54432, 120998, 46416, 22176, 107956, 9680, 37584, 53938, 43344, 46423, 27808, 46416, 86869, 19872, 42416, 83315, 21168, 43432, 59728, 27296, 44710, 43856, 19296, 43748, 42352, 21088, 62051, 55632, 23383, 22176, 38608, 19925, 19152, 42192, 54484, 53840, 54616, 46400, 46752, 103846, 38320, 18864, 43380, 42160, 45690, 27216, 27968, 44870, 43872, 38256, 19189, 18800, 25776, 29859, 59984, 27480, 21952, 43872, 38613, 37600, 51552, 55636, 54432, 55888, 30034, 22176, 43959, 9680, 37584, 51893, 43344, 46240, 47780, 44368, 21977, 19360, 42416, 86390, 21168, 43312, 31060, 27296, 44368, 23378, 19296, 42726, 42208, 53856, 60005, 54576, 23200, 30371, 38608, 19195, 19152, 42192, 118966, 53840, 54560, 56645, 46496, 22224, 21938, 18864, 42359, 42160, 43600, 111189, 27936, 44448, 84835, 37744, 18936, 18800, 25776, 92326, 59984, 27424, 108228, 43744, 41696, 53987, 51552, 54615, 54432, 55888, 23893, 22176, 42704, 21972, 21200, 43448, 43344, 46240, 46758, 44368, 21920, 43940, 42416, 21168, 45683, 26928, 29495, 27296, 44368, 84821, 19296, 42352, 21732, 53600, 59752, 54560, 55968, 92838, 22224, 19168, 43476, 41680, 53584, 62034, 54560]

BASE_SOLAR = date(1900, 1, 31)
MIN_SOLAR = date(1900, 1, 31)
MAX_SOLAR = date(2100, 12, 31)

def _check_year(year):
    if year < 1900 or year > 2100:
        raise ValueError("Calendar Conversion Engine supports years 1900-2100.")

def leap_month(year):
    _check_year(year)
    return LUNAR_INFO[year - 1900] & 0xF

def leap_days(year):
    _check_year(year)
    if leap_month(year):
        return 30 if (LUNAR_INFO[year - 1900] & 0x10000) else 29
    return 0

def month_days(year, month):
    _check_year(year)
    if month < 1 or month > 12:
        raise ValueError("Lunar month must be 1-12.")
    return 30 if (LUNAR_INFO[year - 1900] & (0x10000 >> month)) else 29

def lunar_year_days(year):
    total = 348
    info = LUNAR_INFO[year - 1900]
    # 0x8000 through 0x10: 12 ordinary lunar months.
    for shift in range(15, 3, -1):
        if info & (1 << shift):
            total += 1
    return total + leap_days(year)

def solar_to_lunar(year, month, day):
    solar = date(year, month, day)
    if solar < MIN_SOLAR or solar > MAX_SOLAR:
        raise ValueError("Gregorian date must be between 1900-01-31 and 2100-12-31.")

    offset = (solar - BASE_SOLAR).days

    lunar_year = 1900
    while lunar_year <= 2100:
        days = lunar_year_days(lunar_year)
        if offset < days:
            break
        offset -= days
        lunar_year += 1

    leap = leap_month(lunar_year)
    lunar_month = 1
    is_leap = False

    while lunar_month <= 12:
        if leap and lunar_month == leap + 1 and not is_leap:
            lunar_month -= 1
            is_leap = True
            days = leap_days(lunar_year)
        else:
            days = month_days(lunar_year, lunar_month)

        if offset < days:
            break

        offset -= days

        if is_leap and lunar_month == leap + 1:
            is_leap = False

        lunar_month += 1

    return {
        "year": lunar_year,
        "month": lunar_month,
        "day": offset + 1,
        "is_leap_month": is_leap,
    }

def lunar_date_string(lunar):
    prefix = "閏" if lunar["is_leap_month"] else ""
    return f"{lunar['year']:04d}/{prefix}{lunar['month']:02d}/{lunar['day']:02d}"
